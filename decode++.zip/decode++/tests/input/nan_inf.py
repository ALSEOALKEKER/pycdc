a = 1e300 * 1e300 * 0
b = -1e300 * 1e300 * 0
c = 1e300 * 1e300
d = -1e300 * 1e300
e = float('nan')
f = float('-nan')
g = float('inf')
h = float('-inf')
