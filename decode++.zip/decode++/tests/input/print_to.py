import sys

print >>sys.stdout, 'asdf'
print 'xyz'
print >>sys.stdout, 1, 2, 3, 4
print 5, 6, 7, 8

print >>sys.stdout
print >>sys.stdout, 'Hello World'
print >>sys.stdout

print
print 'Goodbye'
print
